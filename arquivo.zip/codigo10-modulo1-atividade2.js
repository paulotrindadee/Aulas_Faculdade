var texto = "Texto atribuído à variável";

imprimirTexto();

function imprimirTexto(){
	var texto = "Novo texto atribuído à variável";
}

console.log(texto);