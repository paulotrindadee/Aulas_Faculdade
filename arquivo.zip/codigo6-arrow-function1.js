const multiplicacao = (n1, n2) => {
  return n1 * n2;
}
console.log(multiplicacao(3, 2)); //imprimirá 6