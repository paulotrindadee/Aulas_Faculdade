const multiplicacao = (n1, n2) => n1 * n2;
console.log(multiplicacao(3, 5)); //imprimirá 15