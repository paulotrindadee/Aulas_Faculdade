const url = "www.dominio.com.br";

console.log(url); //imprimirá www.dominio.com.br

//gerará um erro, pois uma constante não pode ser 'reatribuida'
url = "www.novo-dominio.com.br"; 