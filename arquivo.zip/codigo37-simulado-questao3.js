for (let i=0;i<5;i++) { 
	var a=0; 
	a++; 
} 

console.log(a); 
i = i - 1; 
console.log(i);
